using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RouletteController : MonoBehaviour
{
    private enum RotDir { Left = 1, Right = -1 }
    private float setRotSpeed = 5;
    private float curRotSpeed = 0;

    private void Update()
    {
        RotateZ(transform, setRotSpeed);
    }

    #region ȸ�� - Z��
    /// <summary>
    /// ȸ�� - Z��
    /// </summary>
    /// <param name="targetTr"></param>
    /// <param name="setRotSpeed"></param>
    /// <param name="decelerationFactor">���� ���</param>
    public void RotateZ(Transform targetTr, float setRotSpeed, float decelerationFactor = 0.995f)
    {
        curRotSpeed = SetRandomRotDir(setRotSpeed) * decelerationFactor;
        targetTr.Rotate(0, 0, curRotSpeed);
    }

    /// <summary>
    /// ȸ�� ������ �������� ����
    /// </summary>
    /// <param name="setRotSpeed"></param>
    /// <returns></returns>
    private float SetRandomRotDir(float setRotSpeed)
    {
        RotDir eRotDir = new();  //ȸ�� ����
        if (Input.GetMouseButtonDown(0))
        {
            if (Mathf.Abs(curRotSpeed) > 0) return 0;  //ȸ�� �� ��Ŭ���ϸ� ����
            int random = Random.Range(-1, 1);  //-1 ~ 0
            if (random == -1) eRotDir = RotDir.Left;
            else if (random == 0) eRotDir = RotDir.Right;
            curRotSpeed = setRotSpeed * (int)eRotDir;
        }
        return curRotSpeed;
    }
    #endregion
}
