using System.Collections;
using UnityEngine;

public class Generator : MonoBehaviour
{
    private UnitController unitController;
    [SerializeField] GameObject generatorUIPrefab, unitPrefab;
    [SerializeField] Transform rallyPoint;
    private GameObject generatorGo;

    private void Awake()
    {
        unitController = FindObjectOfType<UnitController>();
        rallyPoint.position += -Vector3.right * 50;
        rallyPoint.gameObject.SetActive(false);
    }

    public void CreateGeneratorUI()
    {
        if (generatorGo != null) Destroy(generatorGo);
        generatorGo = Instantiate(generatorUIPrefab, transform);
        generatorGo.GetComponent<GeneratorUI>().DynamicAssignment(CreateUnit);
    }

    public void CreateUnit()
    {
        GameObject unitGo = Instantiate(unitPrefab);
        Unit unit = unitGo.GetComponent<Unit>();
        unit.transform.position = transform.position + -Vector3.right * 50;

        Vector3 tempRallyPoint = rallyPoint.position;
        tempRallyPoint.y = unit.transform.position.y;
        rallyPoint.position = tempRallyPoint;
        unit.MoveToRallyPoint(rallyPoint.position);

        unitController.AddUnit(unit);
    }

    public void SetRallyPoint(Vector3 pos)
    {
        rallyPoint.position = pos;

        StartCoroutine(SetRallyPointActiveTime());
    }

    private IEnumerator SetRallyPointActiveTime()
    {
        float activeTime = 0.1f;
        float curTime = 0f;

        while (true)
        {
            if (curTime >= activeTime)
            {
                rallyPoint.gameObject.SetActive(false);
                yield break;
            }

            rallyPoint.gameObject.SetActive(true);
            curTime += Time.deltaTime;
            yield return Time.deltaTime;
        }
    }
}
