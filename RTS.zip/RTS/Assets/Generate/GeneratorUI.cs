using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GeneratorUI : MonoBehaviour
{
    [SerializeField] Button btnProduction;

    public void DynamicAssignment(Action createUnit)
    {
        btnProduction.onClick.AddListener(() => {
            createUnit();
        });
    }
}
