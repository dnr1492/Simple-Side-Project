using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour
{
    [SerializeField] Camera mainCam;
    private Generator generator;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = mainCam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            LayerMask layer = LayerMask.GetMask("Factory");
            if (Physics.Raycast(ray, out hit, Mathf.Infinity, layer))
            {
                generator = hit.collider.GetComponent<Generator>();
                generator.CreateGeneratorUI();
            }
        }

        if (Input.GetKey(KeyCode.R) && Input.GetMouseButtonDown(0) && generator != null)
        {
            Ray ray = mainCam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            LayerMask layer = LayerMask.GetMask("Field");
            if (Physics.Raycast(ray, out hit, Mathf.Infinity, layer))
            {
                Vector3 pos = hit.point;
                pos.y = 0;
                generator.SetRallyPoint(pos);
            }
        }
    }
}
