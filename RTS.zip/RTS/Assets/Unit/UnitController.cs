using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class UnitController : MonoBehaviour
{
    [SerializeField] Camera mainCam;
	private List<GameObject> units = new List<GameObject>();
    private List<GameObject> seletUnits = new List<GameObject>();

    private void Update()
    {
        MoveTo();
    }

    public void AddUnit(Unit unit)
    {
		units.Add(unit.gameObject);
	}

	public void RemoveUnit(Unit unit)
    {
		units.Remove(unit.gameObject);
	}

	public List<GameObject> GetUnits()
	{
		return units;
	}

	public void SelectUnit(Unit unit)
    {
		seletUnits.Add(unit.gameObject);
		unit.SelectUnit();
	}

    public void DeselectUnit(Unit unit)
    {
        seletUnits.Remove(unit.gameObject);
        unit.DeselectUnit();
    }

    public void MoveTo()
    {
        if (Input.GetMouseButtonDown(1))
        {
            if (seletUnits.Count == 0) return;

            Ray ray = mainCam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            LayerMask layer = LayerMask.GetMask("Field");
            if (Physics.Raycast(ray, out hit, Mathf.Infinity, layer))
            {
                for (int i = 0; i < seletUnits.Count; i++)
                {
                    Vector3 hitPoint = hit.point;
                    hitPoint.y = seletUnits[i].transform.position.y;
                    seletUnits[i].GetComponent<Unit>().MoveToRallyPoint(hitPoint);
                };
            }
        }
    }
}