using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Unit : MonoBehaviour
{
    private NavMeshAgent navMeshAgent;
    private float unitSpeed = 50;
    [SerializeField] GameObject unitMarker;

    private void Awake()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        DeselectUnit();
    }

    public void MoveToRallyPoint(Vector3 rallyPoint)
    {
        Vector3 destination = rallyPoint;
        transform.LookAt(destination);
        navMeshAgent.speed = unitSpeed;
        navMeshAgent.acceleration = unitSpeed;
        navMeshAgent.stoppingDistance = unitSpeed;
        navMeshAgent.SetDestination(destination);
    }

    public void SelectUnit()
    {
        unitMarker.SetActive(true);
    }

    public void DeselectUnit()
    {
        unitMarker.SetActive(false);
    }
}
