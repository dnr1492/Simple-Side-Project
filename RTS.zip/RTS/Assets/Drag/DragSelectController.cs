using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragSelectController : MonoBehaviour
{
	[SerializeField] UnitController unitController;
	[SerializeField] Camera mainCam;

	private Rect dragRect;  //���콺�� �巡�� �� ���� (xMin~xMax, yMin~yMax)
	private Vector2 start = Vector2.zero;  //�巡�� ���� ��ġ
	private bool isDrag = false;  //�巡�� ���̸� true �ƴϸ� false

    private void Update()
	{
		UpdateDragSelect();
	}

    #region �巡�׷� ���� ����
    public void UpdateDragSelect()
    {
		if (Input.GetMouseButtonDown(0) && Input.GetKey(KeyCode.Z) || Input.GetMouseButtonDown(0) && Input.GetKey(KeyCode.LeftControl))
		{
			if (Input.GetMouseButtonDown(0))
			{
				start = Input.mousePosition;
				dragRect = new Rect();
				isDrag = true;
			}
		}

		if (isDrag)
		{
			if (Input.GetMouseButtonUp(0))
			{
				CalculateDragRect();
				Select();
				isDrag = false;
			}
		}
	}

	private void CalculateDragRect()
	{
		if (Input.mousePosition.x < start.x)
		{
			dragRect.xMin = Input.mousePosition.x;
			dragRect.xMax = start.x;
		}
		else
		{
			dragRect.xMin = start.x;
			dragRect.xMax = Input.mousePosition.x;
		}

		if (Input.mousePosition.y < start.y)
		{
			dragRect.yMin = Input.mousePosition.y;
			dragRect.yMax = start.y;
		}
		else
		{
			dragRect.yMin = start.y;
			dragRect.yMax = Input.mousePosition.y;
		}
	}

	private void Select()
	{
		List<GameObject> units = unitController.GetUnits();
        for (int i = 0; i < units.Count; i++)
        {
			unitController.DeselectUnit(units[i].GetComponent<Unit>());
		}

		foreach (GameObject unit in units)
		{
			Unit tempUnit = unit.GetComponent<Unit>();
			if (dragRect.Contains(mainCam.WorldToScreenPoint(unit.transform.position))) unitController.SelectUnit(tempUnit);
		}
	}
    #endregion
}
