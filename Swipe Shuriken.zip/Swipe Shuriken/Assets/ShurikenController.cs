using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ShurikenController : MonoBehaviour
{
    [SerializeField] PlayMain playMain;

    private Rigidbody2D shuriken;
    private Vector2 startPos;  //���콺 ���� ��ư�� Ŭ���� ��ǥ
    private Vector2 endPos;  //���콺 ���� ��ư�� ������ �� ��ǥ
    private float rotSpeed = 0;  //ȸ�� �ӵ�

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.name != "Flag") return;
        gameObject.SetActive(false);
        playMain.SetActive(true);
        shuriken.transform.rotation = Quaternion.Euler(Vector3.zero);
        shuriken.velocity = Vector2.zero;
        rotSpeed = 0;
    }

    private void Awake()
    {
        shuriken = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        Swipe();
        Rotate();
    }

    /// <summary>
    /// ��������
    /// </summary>
    private void Swipe()
    {
        if (Input.GetMouseButtonDown(0)) startPos = Input.mousePosition;
        else if (Input.GetMouseButtonUp(0))
        {
            endPos = Input.mousePosition;
            MovePhysics();
            rotSpeed = 10;
        }
        shuriken.velocity *= 0.999f;
    }

    /// <summary>
    /// �̵� - ����
    /// </summary>
    private void MovePhysics()
    {
        shuriken.AddForce((endPos - startPos) * 5);
    }

    /// <summary>
    /// ȸ��
    /// </summary>
    private void Rotate()
    {
        transform.Rotate(0, 0, rotSpeed);  //Z������ ȸ��
        rotSpeed *= 0.999f;  //����
    }
}
