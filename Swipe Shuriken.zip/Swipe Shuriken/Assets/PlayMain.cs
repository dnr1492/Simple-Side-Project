using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayMain : MonoBehaviour
{
    public enum Axis { X, Y, Z }
    [SerializeField] ShurikenController shuriken;
    [SerializeField] GameObject flag;
    [SerializeField] Text txtDistance;
    [SerializeField] Button btnReset;

    private void Awake()
    {
        SetActive(false);
        btnReset.onClick.AddListener(() => {
            shuriken.gameObject.SetActive(true);
            shuriken.transform.position = Vector3.zero;
            SetActive(false);
        });
    }

    private void Update()
    {
        float x = CalDistance(shuriken.gameObject, flag, Axis.X);
        float y = CalDistance(shuriken.gameObject, flag, Axis.Y);
        txtDistance.text = string.Format("��߰��� ���� �Ÿ�" + "\n" + "X�� : {0}" + "\n" + "Y�� : {1}", Mathf.Abs(x).ToString("F0"), Mathf.Abs(y).ToString("F0"));
    }

    #region 2���� ���� ������Ʈ �� ���� �Ÿ��� ���
    /// <summary>
    /// 2���� ���� ������Ʈ �� ���� �Ÿ��� ��� 
    /// </summary>
    /// <param name="start"></param>
    /// <param name="target"></param>
    /// <param name="axis"></param>
    /// <returns></returns>
    public float CalDistance(GameObject start, GameObject target, Axis axis)
    {
        float distance = 0;
        if (axis == Axis.X) distance = target.transform.position.x - start.transform.position.x;
        else if (axis == Axis.Y) distance = target.transform.position.y - start.transform.position.y;
        else if (axis == Axis.Z) distance = target.transform.position.z - start.transform.position.z;
        return distance;
    }
    #endregion

    public void SetActive(bool isActive)
    {
        btnReset.gameObject.SetActive(isActive);
    }
}
