using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ArrowController : MonoBehaviour
{
    private PlayerController player;
    private PlayMain playMain;

    public float radius = 0.5f;  //ȭ���� �浹 ����
    private int arrowScore = 1;  //ȭ���� ���� ��� ȹ���� ����

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, radius);
    }

    private void Awake()
    {
        player = FindObjectOfType<PlayerController>();
        playMain = FindObjectOfType<PlayMain>();
    }

    private void Start()
    {
        playMain.UpdateHpGauge("���� : {0}" + "\n" + "�ִ� : {1}", player.hp, player.maxHp);
    }

    private void Update()
    {
        if (playMain.isGameOver) return;

        transform.Translate(0, -0.01f, 0);

        if (transform.position.y < -4f)
        {
            Destroy(gameObject);
            playMain.arrows.Remove(gameObject);

            playMain.IncreaseScore("{0}��", arrowScore);
        }

        Collide(transform, radius, player.transform, player.radius, DrecreaseHp);
    }

    public void DrecreaseHp()
    {
        player.hp -= 1;
        playMain.UpdateHpGauge("���� : {0}" + "\n" + "�ִ� : {1}", player.hp, player.maxHp);
    }

    #region �浹 ����
    /// <summary>
    /// �浹 ����
    /// </summary>
    /// <param name="target1"></param>
    /// <param name="radius1"></param>
    /// <param name="target2"></param>
    /// <param name="radius2"></param>
    /// <param name="action">�浹 �̺�Ʈ</param>
    public void Collide(Transform target1, float radius1, Transform target2, float radius2, UnityAction action)
    {
        Vector3 pos1 = target1.position;
        Vector3 pos2 = target2.position;
        Vector2 direction = pos2 - pos1;  //pos1���� pos2���� ����
        float distance = direction.magnitude;  //pos1�� pos2 ���� �Ÿ�(����) Ver.1
        //float distance = Vector3.Distance(pos2, pos1);  //pos1�� pos2 ���� �Ÿ�(����) Ver.2
        //float distance = (pos2 - pos1).magnitude;  //pos1�� pos2 ���� �Ÿ�(����) Ver.3
        if (distance < radius1 + radius2)
        {
            action();

            Destroy(target1.gameObject);
            playMain.arrows.Remove(target1.gameObject);
        }
        Debug.DrawLine(pos1, pos2, Color.green);
    }
    #endregion
}
