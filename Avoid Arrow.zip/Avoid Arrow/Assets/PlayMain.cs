using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayMain : MonoBehaviour
{
    [SerializeField] PlayerController player;
    [SerializeField] Camera mainCam;

    [Header("Player")]
    private float moveUp = 0, moveDown = 0, moveLeft = 1, moveRight = 1;
    private float viewportMinX = 0.05f, viewportMaxX = 0.95f, viewportMinY = 0.1f, viewportMaxY = 0.9f;
    //private float minX = -7.82f, maxX = 7.77f;

    [Header("Arrow")]
    [SerializeField] GameObject arrowPrefab;
    [SerializeField] Transform parant;

    [Header("Spawn")]
    private float spawnTime = 0.2f;  //���� �ð�
    private float curSpawnTime = 0;  //���� ���� �ð�

    [Header("Skill")]
    [SerializeField] Button btnSkill;
    [SerializeField] Image imgSkill;
    [SerializeField] Text txtSkill;
    private float skillCoolTime = 5f;
    public List<GameObject> arrows = new List<GameObject>();

    [Header("HP Gauge")]
    [SerializeField] Image imgHpGauge;
    [SerializeField] Text txtHp;

    [Header("Score")]
    [SerializeField] Text txtScore;
    private int totalScore = 0;

    [Header("Total Play Time")]
    [SerializeField] Text txtPlayTime;
    private int playTime = 0;
    private float delta = 0;

    [Header("Game Over")]
    [SerializeField] GameObject gameOverPrefab;
    public bool isGameOver = false;

    private void Awake()
    {
        btnSkill.onClick.AddListener(() =>
        {
            DestroyAllArrow_Skill();
            StartCoroutine(SkillCoolTimeRoutine(skillCoolTime, btnSkill, imgSkill, txtSkill));
        });
    }

    private void Start()
    {
        txtScore.text = string.Format("{0}��", totalScore);
    }

    private void Update()
    {
        if (isGameOver) return;

        //�÷��̾�
        player.UpdateTranslate(player.transform, moveUp, moveDown, moveLeft, moveRight);
        SetScreenBoundary(mainCam, player.transform, viewportMinX, viewportMaxX, viewportMinY, viewportMaxY, false);
        //SetScreenBoundary(player.transform, minX, maxX);

        //ȭ��
        GameObject arrowGo = SpawnGameObject(arrowPrefab, parant, spawnTime);
        if (arrowGo != null)
        {
            float randomX = Random.Range(-8.7f, 8.7f);  //-8.7 ~ 7.7
            arrowGo.transform.position = new Vector3(randomX, 4.44f, 0);
            arrows.Add(arrowGo);
        }

        //�÷��� �ð�
        PlayTime("{0}��");

        //���� ����
        if (player.hp <= 0) GameOver();
    }

    public void DestroyAllArrow_Skill()
    {
        for (int i = 0; i < parant.childCount; i++)
        {
            Destroy(parant.GetChild(i).gameObject);
            arrows.Remove(parant.GetChild(i).gameObject);
        }
    }

    public void IncreaseScore(string txtStr, int score)
    {
        totalScore += score;
        txtScore.text = string.Format(txtStr, totalScore);
    }

    public void GameOver()
    {
        Instantiate(gameOverPrefab);
        isGameOver = true;
        Debug.Log("GAME OVER");
    }

    #region ȭ�� ��� ���� - Viewport
    /// <summary>
    /// ȭ�� ��� ���� - Viewport
    /// </summary>
    /// <param name="cam"></param>
    /// <param name="targetTr"></param>
    /// <param name="viewportMinX"></param>
    /// <param name="viewportMaxX"></param>
    /// <param name="viewportMinY"></param>
    /// <param name="viewportMaxY"></param>
    /// <param name="isDestroy">���� ���� ������ ���� Target ���� ����</param>
    public void SetScreenBoundary(Camera cam, Transform targetTr, float viewportMinX, float viewportMaxX, float viewportMinY, float viewportMaxY, bool isDestroy)
    {
        //(Viewport ����) ī�޶��� ���� �ϴ��� (0.0 , 0.0) �̸�, ���� ����� (1.0 , 1.0)
        Vector3 pos = cam.WorldToViewportPoint(targetTr.position);
        if (isDestroy)
        {
            if (pos.x < viewportMinX) Destroy(targetTr.gameObject);
            if (pos.x > viewportMaxX) Destroy(targetTr.gameObject);
            if (pos.y < viewportMinY) Destroy(targetTr.gameObject);
            if (pos.y > viewportMaxY) Destroy(targetTr.gameObject);
        }
        else
        {
            if (pos.x < viewportMinX) pos.x = viewportMinX;
            if (pos.x > viewportMaxX) pos.x = viewportMaxX;
            if (pos.y < viewportMinY) pos.y = viewportMinY;
            if (pos.y > viewportMaxY) pos.y = viewportMaxY;
            targetTr.position = cam.ViewportToWorldPoint(pos);
        }
    }
    #endregion

    #region ȭ�� ��� ���� - Position X
    public void SetScreenBoundary(Transform targetTr, float minX, float maxX)
    {
        if (targetTr.position.x <= minX)
        {
            var pos = targetTr.position;
            pos.x = minX;
            targetTr.position = pos;
        }
        if (targetTr.position.x >= maxX)
        {
            var pos = targetTr.position;
            pos.x = maxX;
            targetTr.position = pos;
        }
    }
    #endregion

    #region ����
    /// <summary>
    /// ����
    /// </summary>
    /// <param name="prefabGo"></param>
    /// <param name="parant"></param>
    /// <param name="spawnTime"></param>
    /// <param name="resetSpawnTime">���� �ð� �缳�� ����</param>
    /// <returns></returns>
    public GameObject SpawnGameObject(GameObject prefabGo, Transform parant, float spawnTime, bool resetSpawnTime = false)
    {
        if (resetSpawnTime) this.spawnTime = 0;
        if (this.spawnTime == 0) this.spawnTime = spawnTime;

        curSpawnTime += Time.deltaTime;
        if (curSpawnTime >= spawnTime)
        {
            curSpawnTime = 0;
            return Instantiate(prefabGo, parant);
        }

        return null;
    }
    #endregion

    #region ��ų ��Ÿ��
    /// <summary>
    /// ��ų ��Ÿ��
    /// </summary>
    /// <param name="skillCoolTime">��ų ��Ÿ�� �ð�</param>
    /// <param name="skillBtn"></param>
    /// <param name="skillImg"></param>
    /// <param name="skillCoolTimeTxt"></param>
    /// <returns></returns>
    public IEnumerator SkillCoolTimeRoutine(float skillCoolTime, Button skillBtn, Image skillImg, Text skillCoolTimeTxt)
    {
        float remainSkillCoolTime = skillCoolTime;
        string originTxt = skillCoolTimeTxt.text;
        skillImg.fillAmount = 0;

        while (true)
        {
            skillBtn.interactable = false;
            skillCoolTimeTxt.gameObject.SetActive(true);
            skillCoolTimeTxt.text = remainSkillCoolTime.ToString();
            remainSkillCoolTime -= 1;
            skillImg.type = Image.Type.Filled;
            skillImg.fillOrigin = (int)Image.Origin360.Top;
            skillImg.fillAmount += (float)1 / skillCoolTime;
            yield return new WaitForSeconds(1);

            if (remainSkillCoolTime == 0)
            {
                skillBtn.interactable = true;
                skillCoolTimeTxt.text = originTxt;
                skillImg.fillAmount = 360;
                yield break;
            }
        }
    }
    #endregion

    #region HP �������� ���� - Text
    /// <summary>
    /// HP �������� ���� - Text
    /// </summary>
    /// <param name="txtStr"></param>
    /// <param name="hp"></param>
    /// <param name="maxHp"></param>
    /// <returns>HP�� 0�̸� true</returns>
    public bool UpdateHpGauge(string txtStr, float hp, float maxHp)
    {
        txtHp.text = string.Format(txtStr, hp, maxHp);
        float per = hp / maxHp;
        imgHpGauge.type = Image.Type.Filled;
        imgHpGauge.fillOrigin = (int)Image.Origin360.Top;
        imgHpGauge.fillAmount = per;
        if (per <= 0) return true;
        return false;
    }
    #endregion

    #region �÷��� �ð�
    /// <summary>
    /// �÷��� �ð�
    /// </summary>
    /// <param name="txtStr"></param>
    /// <returns>�÷��� �ð�</returns>
    public int PlayTime(string txtStr)
    {
        delta += Time.deltaTime;
        if (delta > 1)
        {
            delta = 0;
            playTime += 1;
            txtPlayTime.text = string.Format(txtStr, playTime);
        }
        return playTime;
    }
    #endregion    
}